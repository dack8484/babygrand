#pragma once

#include "config_common.h"

 

#define COMBO_COUNT 3
#define COMBO_TERM 30
#define TAPPING_TERM 230
#define TAPPING_TERM_PER_KEY
#define IGNORE_MOD_TAP_INTERRUPT
