#pragma once

#include "config_common.h"


#define COMBO_COUNT 1
#define COMBO_TERM 30
